int main() {
  int a = 1;
  int b = 2;
  int c = 0;

  if (a > b) {
    c = 3;
  } else { 
    c = 3;
  }

  int d = c + 1;

  return d;
}

