#!/bin/bash

rm -rf test.c.*
rm -rf test.s
