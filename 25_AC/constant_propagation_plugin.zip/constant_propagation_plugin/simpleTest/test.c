int main() {
  int a = 10;
  int b = a + 5;
  return b;
}
