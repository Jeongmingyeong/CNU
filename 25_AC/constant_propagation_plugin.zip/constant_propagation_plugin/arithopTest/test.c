#include "stdio.h"

int main() {
  int a = 1;
  int b = a + 1;
  int c = b * 2;
  int d = c / 2;
  return 0;
}
