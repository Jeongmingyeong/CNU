#include "stdio.h"

int main() {
  int a = 1;
  int b = a;
  return 0;
}
